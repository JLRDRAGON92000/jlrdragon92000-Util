def	default prompt	\u@\h:\w\$ 	> 	#? 	+ 	:	:					
