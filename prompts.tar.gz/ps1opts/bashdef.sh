bashdef	bash default	\s-\v\$ 	> 	#? 	+ 	:	:					
